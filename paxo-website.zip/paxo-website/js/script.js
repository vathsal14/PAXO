// PAXO Website JavaScript - Enhanced Version

document.addEventListener('DOMContentLoaded', function() {
    
    // Mobile Navigation Toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close mobile menu when clicking on nav links
    document.querySelectorAll('.nav-link').forEach(n => n.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    }));

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Navigation background on scroll
    const navbar = document.querySelector('.navbar');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            navbar.style.backgroundColor = 'rgba(255, 255, 255, 0.98)';
            navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
        } else {
            navbar.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
            navbar.style.boxShadow = 'none';
        }
    });

    // Contact Form Handling
    const contactForm = document.querySelector('.contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const name = this.querySelector('input[type="text"]').value;
            const email = this.querySelector('input[type="email"]').value;
            const phone = this.querySelector('input[type="tel"]').value;
            const businessType = this.querySelector('select').value;
            const message = this.querySelector('textarea').value;
            
            // Simple validation
            if (!name || !email || !phone || !businessType || !message) {
                showNotification('Please fill in all fields', 'error');
                return;
            }
            
            if (!isValidEmail(email)) {
                showNotification('Please enter a valid email address', 'error');
                return;
            }
            
            // Simulate form submission
            showNotification('Thank you! Your message has been sent. We\'ll contact you soon.', 'success');
            this.reset();
        });
    }

    // Newsletter Form Handling
    const newsletterForm = document.querySelector('.newsletter-form');
    
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = this.querySelector('input[type="email"]').value;
            
            if (!email) {
                showNotification('Please enter your email address', 'error');
                return;
            }
            
            if (!isValidEmail(email)) {
                showNotification('Please enter a valid email address', 'error');
                return;
            }
            
            // Simulate newsletter subscription
            showNotification('Thank you for subscribing! You\'ll receive updates soon.', 'success');
            this.reset();
        });
    }

    // Intersection Observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe elements for animations
    const animateElements = document.querySelectorAll('.stat-item, .product-card, .feature-card, .step-card, .testimonial-card, .certification-item, .gallery-item, .popular-item');
    
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });

    // Gallery item hover effects
    const galleryItems = document.querySelectorAll('.gallery-item');
    
    galleryItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });

    // Floating buttons animation
    const floatingButtons = document.querySelectorAll('.floating-btn');
    
    floatingButtons.forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px) scale(1.05)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });

    // City items click effect
    const cityItems = document.querySelectorAll('.city-item');
    
    cityItems.forEach(city => {
        city.addEventListener('click', function() {
            // Remove active class from all cities
            cityItems.forEach(c => c.classList.remove('active'));
            // Add active class to clicked city
            this.classList.add('active');
            
            // Show notification about service availability
            showNotification(`Great! We deliver to ${this.textContent}. Call us for details!`, 'info');
        });
    });

    // Call button click tracking
    document.querySelectorAll('a[href^="tel:"]').forEach(btn => {
        btn.addEventListener('click', function() {
            console.log('Phone call initiated:', this.href);
            trackEvent('Phone Call', 'Contact', this.textContent);
        });
    });

    // WhatsApp button click tracking
    document.querySelectorAll('a[href^="https://wa.me"]').forEach(btn => {
        btn.addEventListener('click', function() {
            console.log('WhatsApp chat initiated:', this.href);
            trackEvent('WhatsApp', 'Contact', 'WhatsApp Chat');
        });
    });

    // Email button click tracking
    document.querySelectorAll('a[href^="mailto:"]').forEach(btn => {
        btn.addEventListener('click', function() {
            console.log('Email initiated:', this.href);
            trackEvent('Email', 'Contact', 'Email Contact');
        });
    });

    // Emergency delivery button special tracking
    document.querySelectorAll('.btn-emergency').forEach(btn => {
        btn.addEventListener('click', function() {
            trackEvent('Emergency Call', 'Contact', 'Emergency Delivery');
        });
    });

    // Consultation button tracking
    document.querySelectorAll('.consultation-cta .btn').forEach(btn => {
        btn.addEventListener('click', function() {
            trackEvent('Consultation', 'Contact', 'Free Consultation');
        });
    });

    // Popular products click tracking
    const popularItems = document.querySelectorAll('.popular-item');
    
    popularItems.forEach(item => {
        item.addEventListener('click', function() {
            const productName = this.querySelector('h4').textContent;
            trackEvent('Product Interest', 'Products', productName);
        });
    });

    // Loading animation for images
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        if (img.complete) {
            img.classList.add('loaded');
        } else {
            img.addEventListener('load', function() {
                this.classList.add('loaded');
            });
        }
    });

    // Add scroll to top button if needed
    const scrollToTopBtn = document.createElement('button');
    scrollToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    scrollToTopBtn.className = 'scroll-to-top';
    scrollToTopBtn.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 20px;
        width: 50px;
        height: 50px;
        background-color: var(--primary-color);
        color: white;
        border: none;
        border-radius: 50%;
        cursor: pointer;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
        z-index: 999;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    `;

    document.body.appendChild(scrollToTopBtn);

    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            scrollToTopBtn.style.opacity = '1';
            scrollToTopBtn.style.visibility = 'visible';
        } else {
            scrollToTopBtn.style.opacity = '0';
            scrollToTopBtn.style.visibility = 'hidden';
        }
    });

    scrollToTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // Add subtle parallax effect to hero section
    const hero = document.querySelector('.hero');
    const heroImg = document.querySelector('.hero-img');
    
    if (hero && heroImg) {
        window.addEventListener('scroll', function() {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.3;
            heroImg.style.transform = `translateY(${rate}px)`;
        });
    }

    // Service area map hover effect
    const serviceMap = document.querySelector('.service-map img');
    
    if (serviceMap) {
        serviceMap.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.05)';
            this.style.transition = 'transform 0.3s ease';
        });
        
        serviceMap.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    }

    // Preload critical images
    const criticalImages = [
        'images/logo.png',
        'images/3d-delivery-truck-packaging-boxes-location-pin-hero-banner.jpg'
    ];

    criticalImages.forEach(src => {
        const img = new Image();
        img.src = src;
    });

    // Add keyboard navigation support
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            // Close mobile menu
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        }
    });

    // Performance optimization: debounce scroll events
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Apply debounce to scroll events
    const debouncedScrollHandler = debounce(function() {
        // Any scroll-based functionality can be added here
    }, 10);

    window.addEventListener('scroll', debouncedScrollHandler);

    // Initialize notification system
    initializeNotifications();

    // Console log for debugging
    console.log('PAXO Enhanced Website JavaScript loaded successfully');
});

// Utility Functions
function formatPhoneNumber(phone) {
    return phone.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function trackEvent(action, category, label) {
    // Placeholder for analytics tracking
    console.log('Event tracked:', { action, category, label });
    
    // You can add Google Analytics or other tracking here
    // Example for Google Analytics 4:
    // gtag('event', action, {
    //     event_category: category,
    //     event_label: label
    // });
}

function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notif => notif.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#17a2b8'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        font-weight: 500;
        max-width: 300px;
        animation: slideInRight 0.3s ease;
    `;
    
    // Add animation styles
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideInRight 0.3s ease reverse';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
    
    // Click to dismiss
    notification.addEventListener('click', () => {
        notification.style.animation = 'slideInRight 0.3s ease reverse';
        setTimeout(() => {
            notification.remove();
        }, 300);
    });
}

function initializeNotifications() {
    // Add notification styles to head
    const style = document.createElement('style');
    style.textContent = `
        .notification {
            cursor: pointer;
            user-select: none;
        }
        .notification:hover {
            opacity: 0.9;
        }
    `;
    document.head.appendChild(style);
}

// Product quantity calculator (for future use)
function calculateQuantity(type, usage, days) {
    // This function can be used for a more advanced product calculator
    const multipliers = {
        'restaurant': 1.5,
        'cafe': 1.2,
        'catering': 2.0,
        'food-truck': 1.3
    };
    
    const multiplier = multipliers[type] || 1.0;
    return Math.ceil(usage * multiplier * days);
}

// Service area checker (for future use)
function checkServiceArea(city) {
    const serviceAreas = [
        'Hyderabad', 'Vijayawada', 'Chennai', 'Bangalore', 
        'Mumbai', 'Pune', 'Delhi', 'Kolkata'
    ];
    
    return serviceAreas.includes(city);
}

// Export functions for external use if needed
window.PAXOWebsite = {
    formatPhoneNumber,
    trackEvent,
    showNotification,
    isValidEmail,
    calculateQuantity,
    checkServiceArea
};

// Add some fun easter eggs for engaged users
let clickCount = 0;
document.addEventListener('click', function(e) {
    clickCount++;
    
    // Special message after multiple clicks on logo
    if (e.target.classList.contains('logo-img') && clickCount === 10) {
        showNotification('You really love our logo! 🎉 Thanks for exploring!', 'success');
    }
    
    // Hidden feature after many interactions
    if (clickCount === 50) {
        showNotification('Wow! You\'re really exploring everything. Here\'s a surprise: Call us for VIP pricing!', 'info');
    }
});

// Service Worker Registration (for future PWA features)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // Uncomment when you have a service worker file
        // navigator.serviceWorker.register('/sw.js')
        //     .then(registration => console.log('SW registered'))
        //     .catch(error => console.log('SW registration failed'));
    });
}

// Performance monitoring
if ('performance' in window) {
    window.addEventListener('load', function() {
        setTimeout(() => {
            const perfData = performance.getEntriesByType('navigation')[0];
            console.log('Page load time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms');
        }, 0);
    });
}